#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  Vagabond Ragchew Net — Start
#
#  Flask runs on port 8080 internally.
#  nginx proxies http://localhost (port 80) → 8080.
#  No sudo required to start Flask.
# ─────────────────────────────────────────────────────────────
set -e
cd "$(dirname "$0")"

PYTHON=$(command -v python3 || command -v python || true)
if [ -z "$PYTHON" ]; then
  echo "Error: Python 3 not found."
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "Creating virtual environment..."
  $PYTHON -m venv .venv
fi
source .venv/bin/activate
pip install flask --quiet

if [ ! -f "ham_radio.db" ]; then
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  First run — downloading FCC license database (~150 MB)"
  echo "  This takes about 2 minutes."
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  python import_data.py
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Vagabond Ragchew Net — starting"
echo "  Flask on port 8080, proxied via nginx to port 80"
echo "  Open  ►  http://localhost  in your browser"
echo "  Database rebuilds automatically every 24 hours."
echo "  Press Ctrl+C to stop everything."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

python scheduler.py
