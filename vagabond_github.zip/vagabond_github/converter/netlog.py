"""
netlog.py - Parse NetLogger-style check-ins .log files.

Shared by the CLI tool and the Flask admin route, so the field mapping
lives in exactly one place.

Log format (pipe-delimited, blank fields are a single space "| |"):
  1  Serial number          8  Status flags e.g. (nc),(m),(op)
  2  Callsign               11 County
  3  State                  12 Grid square
  4  Remarks                13 Street address
  5  QSL Info               14 ZIP
  6  City                   15 DXCC entity number
  7  Full name              19 Country
                            20 Preferred/first name (Operator)
"""

import csv
import io
import re
from dataclasses import dataclass, field, asdict

COLUMNS = [
    "Date", "Time", "Callsign", "Frequency", "Mode", "Band", "DXCC",
    "His_RST", "My_RST", "Name", "City", "State", "County", "Grid",
    "QSL_S", "QSL_R", "Remarks", "Address", "Net Name", "Operator",
    "QSL Info", "QSL Message",
]

FILENAME_DT = re.compile(r"(\d{2})-(\d{2})-(\d{4})-(\d{2})-(\d{2})")


@dataclass
class NetDefaults:
    frequency: str = ""
    mode: str = ""
    band: str = ""
    net_name: str = ""
    dedupe: bool = False


def parse_filename_datetime(filename: str):
    """CheckInsOn07-18-2026-12-54.log -> ('2026-07-18', '12:54')"""
    m = FILENAME_DT.search(filename)
    if not m:
        return "", ""
    mm, dd, yyyy, hh, mi = m.groups()
    return f"{yyyy}-{mm}-{dd}", f"{hh}:{mi}"


def _title_if_shouting(s: str) -> str:
    return s.title() if s.isupper() else s


def parse_log(text: str, filename: str, defaults: NetDefaults):
    """Yield one dict per check-in, keyed by COLUMNS."""
    date_str, time_str = parse_filename_datetime(filename)
    seen = set()

    for raw in text.splitlines():
        if not raw.strip():
            continue
        parts = [p.strip() for p in raw.split("|")]
        parts += [""] * max(0, 20 - len(parts))

        (_, callsign, state, remarks, qsl_info, city, name, flags,
         _, _, county, grid, street, zipcode, dxcc, _, _, _, _country,
         op_name) = parts[:20]

        if not callsign:
            continue
        if defaults.dedupe:
            if callsign in seen:
                continue
            seen.add(callsign)

        yield {
            "Date": date_str,
            "Time": time_str,
            "Callsign": callsign,
            "Frequency": defaults.frequency,
            "Mode": defaults.mode,
            "Band": defaults.band,
            "DXCC": dxcc,
            "His_RST": "",
            "My_RST": "",
            "Name": name,
            "City": _title_if_shouting(city),
            "State": state,
            "County": county,
            "Grid": grid,
            "QSL_S": "",
            "QSL_R": "",
            "Remarks": " ".join(x for x in (remarks, flags) if x),
            "Address": ", ".join(x for x in (street, zipcode) if x),
            "Net Name": defaults.net_name,
            "Operator": op_name,
            "QSL Info": qsl_info,
            "QSL Message": "",
        }


def rows_to_csv(rows) -> str:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=COLUMNS, lineterminator="\r\n")
    writer.writeheader()
    writer.writerows(rows)
    return buf.getvalue()
