#!/usr/bin/env python3
"""
Download and import FCC ULS Amateur Radio license data into SQLite.
Run this once before starting the Flask app, then let scheduler.py
handle subsequent refreshes every 24 hours.

Data source: https://data.fcc.gov/download/pub/uls/complete/l_amat.zip
Updated weekly by the FCC.

Memory-efficient: streams each .dat file directly into SQLite temp tables
using small batches — never loads more than ~1,000 rows into RAM at a time.
Works on low-memory machines (Raspberry Pi, small VPS, etc.)
"""

import os, sys, sqlite3, zipfile, urllib.request, time

DB_PATH  = "ham_radio.db"
ULS_URL  = "https://data.fcc.gov/download/pub/uls/complete/l_amat.zip"
ZIP_PATH = "l_amat.zip"
BATCH    = 1000   # rows per INSERT — tiny footprint, safe on any machine

CLASS_LABELS = {
    "N": "Novice",
    "T": "Technician",
    "G": "General",
    "A": "Amateur Extra",       # FCC code is A (Advanced) but ULS uses E for Extra
    "E": "Amateur Extra",
    "P": "Technician Plus",
    "X": "Advanced",
}

# ── DOWNLOAD ──────────────────────────────────────────────────────────────────
def download_data():
    print(f"Downloading FCC ULS amateur radio database (~100-200 MB)...")
    print(f"Source: {ULS_URL}\n")
    last_pct = [-1]

    def progress(block_num, block_size, total_size):
        downloaded = block_num * block_size
        if total_size > 0:
            pct = min(100, downloaded * 100 // total_size)
            if pct != last_pct[0]:
                mb       = downloaded / 1_048_576
                total_mb = total_size / 1_048_576
                bar      = "█" * (pct // 5) + "░" * (20 - pct // 5)
                print(f"\r  [{bar}] {pct:3d}%  {mb:.1f}/{total_mb:.1f} MB",
                      end="", flush=True)
                last_pct[0] = pct

    urllib.request.urlretrieve(ULS_URL, ZIP_PATH, reporthook=progress)
    print("\n  Download complete.\n")

# ── SCHEMA ────────────────────────────────────────────────────────────────────
def create_schema(conn):
    conn.executescript("""
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous  = NORMAL;
        PRAGMA temp_store   = FILE;
        PRAGMA cache_size   = -8000;

        DROP TABLE IF EXISTS licenses;
        DROP TABLE IF EXISTS _am;
        DROP TABLE IF EXISTS _hd;

        -- Permanent licenses table
        CREATE TABLE licenses (
            uid         INTEGER PRIMARY KEY,
            call_sign   TEXT,
            first_name  TEXT,
            last_name   TEXT,
            entity_name TEXT,
            street      TEXT,
            city        TEXT,
            state       TEXT,
            zip         TEXT,
            email       TEXT,
            op_class    TEXT,
            status      TEXT
        );

        -- Temporary staging tables (deleted at end)
        CREATE TABLE _am (uid INTEGER PRIMARY KEY, op_class TEXT);
        CREATE TABLE _hd (uid INTEGER PRIMARY KEY, status   TEXT);
    """)
    conn.commit()

# ── STREAM A DAT FILE INTO A TEMP TABLE ───────────────────────────────────────
def stream_dat(conn, zf, filename, table, col, field_uid, field_val, label):
    """
    Read a .dat file from the zip one line at a time and insert into
    a SQLite staging table in BATCH-sized chunks. Never holds more than
    BATCH rows in memory.
    """
    print(f"  Streaming {filename} → {label}...")
    batch  = []
    count  = 0
    sql    = f"INSERT OR REPLACE INTO {table} VALUES (?,?)"
    t0     = time.time()

    try:
        with zf.open(filename) as f:
            for raw in f:
                parts = raw.decode("latin-1").rstrip("\r\n").split("|")
                if len(parts) <= max(field_uid, field_val):
                    continue
                uid = parts[field_uid].strip()
                val = parts[field_val].strip()
                if not uid or not uid.isdigit():
                    continue
                batch.append((int(uid), val))
                count += 1
                if len(batch) >= BATCH:
                    conn.executemany(sql, batch)
                    conn.commit()
                    batch.clear()
                    print(f"\r  Streaming {filename}... {count:,}", end="", flush=True)

        if batch:
            conn.executemany(sql, batch)
            conn.commit()

    except KeyError:
        print(f"\n  Warning: {filename} not found in zip — skipping.")
        return 0

    print(f"\r  {filename}: {count:,} records in {time.time()-t0:.1f}s")
    return count

# ── STREAM EN.DAT AND JOIN AGAINST TEMP TABLES ────────────────────────────────
def stream_en(conn, zf):
    """
    Read EN.dat one line at a time, look up op_class and status from
    SQLite (not in-memory dicts), and insert into licenses in batches.

    EN.dat fields:
     0=RecType  1=UID  2=ULSFileNum  3=EBFNum  4=CallSign  5=EntityType
     6=LicenseeID  7=EntityName  8=FirstName  9=MI  10=LastName  11=Suffix
     12=Phone  13=Fax  14=Email  15=Street  16=City  17=State  18=Zip
    """
    print("  Streaming EN.dat (licensees) → licenses...")

    # Pre-load status + class lookup into a joined dict — but in batches
    # Actually: just do row-by-row SQLite lookups with a cached cursor.
    # SQLite with WAL is fast enough; we avoid any large in-memory structure.

    sql_ins = """
        INSERT OR REPLACE INTO licenses
        SELECT
            e.uid,
            e.call_sign,
            e.first_name,
            e.last_name,
            e.entity_name,
            e.street,
            e.city,
            e.state,
            e.zip,
            e.email,
            COALESCE(a.op_class, ''),
            CASE h.status
                WHEN 'A' THEN 'Active'
                WHEN 'E' THEN 'Expired'
                WHEN 'C' THEN 'Cancelled'
                WHEN 'T' THEN 'Terminated'
                ELSE COALESCE(h.status, '')
            END
        FROM _en_staging e
        LEFT JOIN _am a ON a.uid = e.uid
        LEFT JOIN _hd h ON h.uid = e.uid
    """

    # Create a tiny staging table for the current EN batch
    conn.execute("DROP TABLE IF EXISTS _en_staging")
    conn.execute("""
        CREATE TABLE _en_staging (
            uid INTEGER, call_sign TEXT, first_name TEXT, last_name TEXT,
            entity_name TEXT, street TEXT, city TEXT, state TEXT,
            zip TEXT, email TEXT
        )
    """)
    conn.commit()

    sql_stage = "INSERT INTO _en_staging VALUES (?,?,?,?,?,?,?,?,?,?)"
    batch = []
    count = 0
    t0    = time.time()

    try:
        with zf.open("EN.dat") as f:
            for raw in f:
                parts = raw.decode("latin-1").rstrip("\r\n").split("|")
                if len(parts) < 17:
                    continue
                uid       = parts[1].strip()
                call_sign = parts[4].strip()
                if not uid or not uid.isdigit() or not call_sign:
                    continue

                batch.append((
                    int(uid),
                    call_sign,
                    parts[8].strip()  if len(parts) > 8  else "",   # first
                    parts[10].strip() if len(parts) > 10 else "",   # last
                    parts[7].strip()  if len(parts) > 7  else "",   # entity
                    parts[15].strip() if len(parts) > 15 else "",   # street
                    parts[16].strip() if len(parts) > 16 else "",   # city
                    parts[17].strip() if len(parts) > 17 else "",   # state
                    parts[18].strip()[:5] if len(parts) > 18 else "", # zip
                    parts[14].strip() if len(parts) > 14 else "",   # email
                ))
                count += 1

                if len(batch) >= BATCH:
                    conn.executemany(sql_stage, batch)
                    conn.execute(sql_ins)
                    conn.execute("DELETE FROM _en_staging")
                    conn.commit()
                    batch.clear()
                    elapsed = time.time() - t0
                    print(f"\r  EN.dat: {count:,} records ({elapsed:.0f}s)...",
                          end="", flush=True)

        # Final batch
        if batch:
            conn.executemany(sql_stage, batch)
            conn.execute(sql_ins)
            conn.execute("DELETE FROM _en_staging")
            conn.commit()

    except KeyError:
        print("\n  ERROR: EN.dat not found in zip.")
        return 0

    print(f"\r  EN.dat: {count:,} records imported in {time.time()-t0:.1f}s")
    return count

# ── APPLY CLASS LABELS ────────────────────────────────────────────────────────
def apply_class_labels(conn):
    """Translate single-letter FCC codes to human-readable class names."""
    print("  Applying license class labels...")
    for code, label in CLASS_LABELS.items():
        conn.execute(
            "UPDATE licenses SET op_class = ? WHERE op_class = ?",
            (label, code)
        )
    conn.commit()

# ── INDEXES ──────────────────────────────────────────────────────────────────
def build_indexes(conn):
    print("Building search indexes...")
    conn.executescript("""
        CREATE INDEX IF NOT EXISTS idx_callsign ON licenses(call_sign);
        CREATE INDEX IF NOT EXISTS idx_lastname ON licenses(last_name);
        CREATE INDEX IF NOT EXISTS idx_city     ON licenses(city);
        CREATE INDEX IF NOT EXISTS idx_state    ON licenses(state);
        CREATE INDEX IF NOT EXISTS idx_class    ON licenses(op_class);
        CREATE INDEX IF NOT EXISTS idx_status   ON licenses(status);
    """)
    conn.commit()
    print("  Indexes built.\n")

# ── CLEANUP TEMP TABLES ───────────────────────────────────────────────────────
def cleanup(conn):
    conn.executescript("""
        DROP TABLE IF EXISTS _am;
        DROP TABLE IF EXISTS _hd;
        DROP TABLE IF EXISTS _en_staging;
    """)
    conn.commit()

# ── MAIN ─────────────────────────────────────────────────────────────────────
def main():
    if os.path.exists(DB_PATH):
        ans = input(f"'{DB_PATH}' already exists. Re-import? [y/N] ").strip().lower()
        if ans != "y":
            print("Aborted.")
            sys.exit(0)
        os.remove(DB_PATH)

    if not os.path.exists(ZIP_PATH):
        download_data()
    else:
        size_mb = os.path.getsize(ZIP_PATH) / 1_048_576
        print(f"Found existing '{ZIP_PATH}' ({size_mb:.0f} MB) — skipping download.")
        print("Delete it to force a fresh download.\n")

    print("Setting up database...")
    conn = sqlite3.connect(DB_PATH)
    create_schema(conn)
    print("  Schema created.\n")

    print("Importing data (streaming — low memory usage)...")
    with zipfile.ZipFile(ZIP_PATH) as zf:
        stream_dat(conn, zf, "AM.dat", "_am", "op_class", 1, 5, "operator classes")
        stream_dat(conn, zf, "HD.dat", "_hd", "status",   1, 5, "license statuses")
        count = stream_en(conn, zf)

    apply_class_labels(conn)
    build_indexes(conn)
    cleanup(conn)
    conn.close()

    size_mb = os.path.getsize(DB_PATH) / 1_048_576
    print(f"✓  Database ready: {DB_PATH}")
    print(f"   {count:,} operators  |  {size_mb:.0f} MB on disk")
    print("\nNow run:  ./start.sh\n")

if __name__ == "__main__":
    main()
