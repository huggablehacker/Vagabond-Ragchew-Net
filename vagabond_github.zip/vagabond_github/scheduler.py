#!/usr/bin/env python3
"""
Vagabond Ragchew Net — Scheduler / Watchdog
============================================
Manages app.py as a child process. Every 24 hours (or at the
configured time) it:

  1. Gracefully stops app.py
  2. Re-downloads the FCC data and rebuilds ham_radio.db
  3. Restarts app.py

Also writes scheduler_status.json so the website can show
live countdown / last-rebuild info without any extra IPC.

Usage:
    sudo .venv/bin/python scheduler.py          # normal start via start.sh
    sudo .venv/bin/python scheduler.py --now    # force an immediate rebuild then start
"""

import subprocess, sys, os, time, signal, json, argparse, logging
from datetime import datetime, timedelta
from pathlib import Path

# ── CONFIG ────────────────────────────────────────────────────────────────────
BASE_DIR       = Path(__file__).parent.resolve()
PYTHON         = sys.executable
APP_SCRIPT     = str(BASE_DIR / "app.py")
IMPORT_SCRIPT  = str(BASE_DIR / "import_data.py")
STATUS_FILE    = str(BASE_DIR / "scheduler_status.json")
LOG_FILE       = str(BASE_DIR / "scheduler.log")
REBUILD_EVERY  = 24 * 60 * 60   # seconds — change to e.g. 12 * 3600 for 12 h
RESTART_DELAY  = 5               # seconds between stop and start — gives port 80 time to release
CHECK_INTERVAL = 15              # how often the main loop wakes to check timers

# ── LOGGING ───────────────────────────────────────────────────────────────────
log_fmt = "%(asctime)s  %(levelname)-8s  %(message)s"
logging.basicConfig(
    level=logging.INFO,
    format=log_fmt,
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("scheduler")

# ── STATE ─────────────────────────────────────────────────────────────────────
app_proc      = None
shutdown_flag = False

# ── STATUS FILE ───────────────────────────────────────────────────────────────
def write_status(next_rebuild_dt, last_rebuild_dt=None, last_status="pending", count=0):
    data = {
        "scheduler_started":  datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "next_rebuild_at":    next_rebuild_dt.strftime("%Y-%m-%dT%H:%M:%S"),
        "next_rebuild_in_s":  max(0, int((next_rebuild_dt - datetime.now()).total_seconds())),
        "last_rebuild_at":    last_rebuild_dt.strftime("%Y-%m-%dT%H:%M:%S") if last_rebuild_dt else None,
        "last_rebuild_status": last_status,
        "rebuild_count":      count,
        "rebuild_interval_h": REBUILD_EVERY // 3600,
    }
    try:
        with open(STATUS_FILE, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        log.warning(f"Could not write status file: {e}")

# ── APP PROCESS ───────────────────────────────────────────────────────────────
def start_app():
    global app_proc
    log.info("▶  Starting app.py ...")
    log_file = open(LOG_FILE, "a")   # append app.py output into same log
    app_proc = subprocess.Popen(
        [PYTHON, APP_SCRIPT],
        cwd=str(BASE_DIR),
        stdout=log_file,
        stderr=log_file,
    )
    log.info(f"   app.py running  (PID {app_proc.pid})")

def stop_app():
    global app_proc
    if app_proc is None:
        return
    if app_proc.poll() is not None:
        log.info(f"   app.py already exited (code {app_proc.returncode})")
        app_proc = None
        return
    log.info(f"■  Stopping app.py (PID {app_proc.pid}) ...")
    app_proc.terminate()
    try:
        app_proc.wait(timeout=10)
        log.info("   app.py stopped cleanly.")
    except subprocess.TimeoutExpired:
        log.warning("   app.py didn't terminate — sending SIGKILL.")
        app_proc.kill()
        app_proc.wait()
    app_proc = None

# ── DATABASE REBUILD ──────────────────────────────────────────────────────────
def rebuild_database():
    log.info("━" * 54)
    log.info("⟳  FCC database rebuild starting ...")
    log.info(f"   Running: {IMPORT_SCRIPT}")
    log.info("━" * 54)
    try:
        result = subprocess.run(
            [PYTHON, IMPORT_SCRIPT],
            cwd=str(BASE_DIR),
            timeout=45 * 60,   # 45-minute hard cap for download + SQLite import
        )
        if result.returncode == 0:
            log.info("✓  Database rebuild finished successfully.")
            return True
        else:
            log.error(f"✗  import_data.py exited with code {result.returncode}.")
            return False
    except subprocess.TimeoutExpired:
        log.error("✗  Rebuild timed out after 45 minutes — keeping existing database.")
        return False
    except FileNotFoundError:
        log.error(f"✗  import_data.py not found at {IMPORT_SCRIPT}")
        return False
    except Exception as e:
        log.error(f"✗  Rebuild failed: {e}")
        return False

# ── SIGNAL HANDLING ───────────────────────────────────────────────────────────
def on_signal(signum, frame):
    global shutdown_flag
    log.info(f"Signal {signum} received — shutting down gracefully.")
    shutdown_flag = True
    stop_app()
    # Remove status file so website knows scheduler isn't running
    try:
        os.remove(STATUS_FILE)
    except FileNotFoundError:
        pass
    sys.exit(0)

signal.signal(signal.SIGTERM, on_signal)
signal.signal(signal.SIGINT,  on_signal)

# ── MAIN LOOP ─────────────────────────────────────────────────────────────────
def main():
    global app_proc  # required — main() assigns app_proc = None in the watchdog loop

    parser = argparse.ArgumentParser()
    parser.add_argument("--now", action="store_true",
                        help="Run an immediate database rebuild before starting the app.")
    parser.add_argument("--interval", type=int, default=REBUILD_EVERY,
                        help="Override rebuild interval in seconds (default: 86400)")
    args = parser.parse_args()

    rebuild_interval = args.interval
    rebuild_count    = 0
    last_rebuild_dt  = None
    last_status      = "pending"

    log.info("=" * 54)
    log.info("  Vagabond Ragchew Net — Scheduler")
    log.info(f"  Rebuild every {rebuild_interval // 3600}h {(rebuild_interval % 3600) // 60}m")
    log.info("=" * 54)

    # Optional immediate rebuild on startup
    if args.now:
        log.info("--now flag set: running initial rebuild before starting app.")
        ok = rebuild_database()
        rebuild_count += 1
        last_rebuild_dt = datetime.now()
        last_status = "success" if ok else "failed"

    # Start the app
    start_app()

    next_rebuild_dt = datetime.now() + timedelta(seconds=rebuild_interval)
    log.info(f"Next rebuild: {next_rebuild_dt.strftime('%Y-%m-%d %H:%M:%S')}")
    write_status(next_rebuild_dt, last_rebuild_dt, last_status, rebuild_count)

    # ── Main watchdog + scheduler loop ────────────────────────────────────────
    while not shutdown_flag:
        time.sleep(CHECK_INTERVAL)

        # Watchdog: restart app if it crashed
        if app_proc and app_proc.poll() is not None:
            code = app_proc.returncode
            log.warning(f"app.py exited unexpectedly (code {code}) — restarting in {RESTART_DELAY}s ...")
            log.warning(f"  ► Check scheduler.log for the error output from app.py above this line.")
            app_proc = None
            time.sleep(RESTART_DELAY)
            start_app()

        # Update countdown in status file every loop
        write_status(next_rebuild_dt, last_rebuild_dt, last_status, rebuild_count)

        # Rebuild check
        if datetime.now() >= next_rebuild_dt:
            log.info("24-hour mark reached — beginning rebuild cycle.")

            stop_app()
            time.sleep(RESTART_DELAY)

            ok = rebuild_database()
            rebuild_count += 1
            last_rebuild_dt = datetime.now()
            last_status = "success" if ok else "failed"

            if not ok:
                log.warning("Rebuild failed — restarting app with the existing database.")

            start_app()

            next_rebuild_dt = datetime.now() + timedelta(seconds=rebuild_interval)
            log.info(f"Next rebuild: {next_rebuild_dt.strftime('%Y-%m-%d %H:%M:%S')}")
            write_status(next_rebuild_dt, last_rebuild_dt, last_status, rebuild_count)


if __name__ == "__main__":
    main()
