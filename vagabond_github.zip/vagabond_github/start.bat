@echo off
REM Vagabond Ragchew Net — Start (Windows)
REM Flask runs on port 8080; no Administrator rights needed.

cd /d "%~dp0"

if not exist ".venv" (
    echo Creating virtual environment...
    python -m venv .venv
)
call .venv\Scripts\activate.bat
pip install flask --quiet

if not exist "ham_radio.db" (
    echo.
    echo ══════════════════════════════════════════════════════
    echo   First run - downloading FCC database ~150 MB
    echo   This takes about 2 minutes.
    echo ══════════════════════════════════════════════════════
    python import_data.py
)

echo.
echo ══════════════════════════════════════════════════════
echo   Vagabond Ragchew Net - starting on port 8080
echo   Open  ^►  http://localhost:8080  in your browser
echo   Press Ctrl+C to stop.
echo ══════════════════════════════════════════════════════
echo.
python scheduler.py
pause
