#!/usr/bin/env python3
"""
Vagabond Ragchew Net — Ham Radio Lookup Backend
Flask app serving the FCC amateur radio license database.

Startup:
    pip install flask
    python import_data.py    # first run only — downloads & imports FCC data (~2 min)
    python app.py

Visit http://localhost — Flask serves vagabondnet.html and the API.
"""

import sqlite3, os, json, io, functools
from datetime import datetime
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory, send_file, Response
from converter.netlog import parse_log, rows_to_csv, NetDefaults

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024   # 4 MB upload cap

# ── ADMIN CREDENTIALS ─────────────────────────────────────────────────────────
# Set via environment variables or a .env file (see .env.example).
# Never commit real credentials to git.
def _load_env():
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    os.environ.setdefault(k.strip(), v.strip())

_load_env()

ADMIN_USER     = os.environ.get("ADMIN_USER",     "test")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "test")

if ADMIN_PASSWORD == "changeme":
    print("⚠  WARNING: Admin password is still 'test'. "
          "Set ADMIN_PASSWORD in your .env file before deploying.")

def check_auth(username, password):
    return username == ADMIN_USER and password == ADMIN_PASSWORD

def admin_required(view):
    """HTTP Basic Auth decorator — browser shows a login prompt."""
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return Response(
                "Admin access required.",
                401,
                {"WWW-Authenticate": 'Basic realm="Vagabond Admin"'}
            )
        return view(*args, **kwargs)
    return wrapped

CHECKINS_DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "checkins.db")

def init_checkins_db():
    with sqlite3.connect(CHECKINS_DB) as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                id          INTEGER PRIMARY KEY,
                net_date    TEXT, net_time TEXT, net_name TEXT,
                frequency   TEXT, mode TEXT, band TEXT,
                source_file TEXT,
                imported_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS checkins (
                id          INTEGER PRIMARY KEY,
                session_id  INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
                callsign    TEXT, name TEXT, operator TEXT,
                city        TEXT, state TEXT, county TEXT, grid TEXT,
                dxcc        TEXT, remarks TEXT, address TEXT, qsl_info TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_checkins_call ON checkins(callsign);
        """)

init_checkins_db()
DB_PATH = os.path.join(os.path.dirname(__file__), "ham_radio.db")

OPERATOR_CLASSES = ["","Amateur Extra","General","Advanced","Technician","Technician Plus","Novice"]
US_STATES = ["","AK","AL","AR","AZ","CA","CO","CT","DC","DE","FL","GA","HI",
    "IA","ID","IL","IN","KS","KY","LA","MA","MD","ME","MI","MN","MO",
    "MS","MT","NC","ND","NE","NH","NJ","NM","NV","NY","OH","OK","OR",
    "PA","PR","RI","SC","SD","TN","TX","UT","VA","VI","VT","WA","WI","WV","WY"]

# ── DB HELPERS ────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def db_exists():
    return os.path.exists(DB_PATH)

def migrate_db():
    if not db_exists():
        return
    conn = sqlite3.connect(DB_PATH)
    try:
        existing = {row[1] for row in conn.execute("PRAGMA table_info(licenses)")}
        if "email" not in existing:
            print("Migrating DB: adding email column...")
            conn.execute("ALTER TABLE licenses ADD COLUMN email TEXT DEFAULT ''")
            conn.commit()
            print("Done. Re-run import_data.py for full email data.")
    except Exception as e:
        print(f"Migration warning: {e}")
    finally:
        conn.close()

migrate_db()

def init_history_table():
    """Create lookup_history table if it doesn't exist yet."""
    if not db_exists():
        return
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS lookup_history (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                call_sign     TEXT NOT NULL,
                operator_name TEXT DEFAULT '',
                op_class      TEXT DEFAULT '',
                status        TEXT DEFAULT '',
                city          TEXT DEFAULT '',
                state         TEXT DEFAULT '',
                looked_up_at  TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime')),
                notes         TEXT DEFAULT ''
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_hist_call ON lookup_history(call_sign)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_hist_time ON lookup_history(looked_up_at DESC)")
        conn.commit()
    except Exception as e:
        print(f"History table init warning: {e}")
    finally:
        conn.close()

init_history_table()

# ── ROUTES ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    # Serve vagabondnet.html directly so the page and API share the same origin.
    # Browser visit: http://localhost
    return send_from_directory(os.path.dirname(os.path.abspath(__file__)), "vagabondnet.html")

@app.route("/files/<path:filename>")
def serve_file(filename):
    """Serve PDFs and static files from the local files/ directory."""
    files_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "files")
    return send_from_directory(files_dir, filename)

@app.route("/search")
def search():
    if not db_exists():
        return jsonify({"error": "Database not found. Run import_data.py first.",
                        "results": [], "total": 0})

    call_sign  = request.args.get("callsign",  "").strip().upper()
    last_name  = request.args.get("lastname",  "").strip()
    first_name = request.args.get("firstname", "").strip()
    city       = request.args.get("city",      "").strip()
    state      = request.args.get("state",     "").strip().upper()
    op_class   = request.args.get("opclass",   "").strip()
    status     = request.args.get("status",    "").strip()
    page       = max(1, int(request.args.get("page", 1)))
    per_page   = 50

    if not any([call_sign, last_name, first_name, city, state, op_class]):
        return jsonify({"results": [], "total": 0, "page": page, "pages": 0})

    conditions, params = [], []
    if call_sign:  conditions.append("call_sign LIKE ?");  params.append(call_sign + "%")
    if last_name:  conditions.append("last_name LIKE ?");  params.append(last_name + "%")
    if first_name: conditions.append("first_name LIKE ?"); params.append(first_name + "%")
    if city:       conditions.append("city LIKE ?");       params.append(city + "%")
    if state:      conditions.append("state = ?");         params.append(state)
    if op_class:   conditions.append("op_class = ?");      params.append(op_class)
    if status:     conditions.append("status = ?");        params.append(status)

    where    = " AND ".join(conditions)
    base_sql = f"FROM licenses WHERE {where}"

    try:
        conn   = get_db()
        total  = conn.execute(f"SELECT COUNT(*) {base_sql}", params).fetchone()[0]
        offset = (page - 1) * per_page
        rows   = conn.execute(
            f"SELECT call_sign, first_name, last_name, entity_name, street, city, state, zip, "
            f"COALESCE(email,'') as email, op_class, status "
            f"{base_sql} ORDER BY call_sign LIMIT ? OFFSET ?",
            params + [per_page, offset]
        ).fetchall()
        conn.close()
    except Exception as e:
        return jsonify({"error": str(e), "results": [], "total": 0, "page": page, "pages": 0})

    return jsonify({
        "results":  [dict(r) for r in rows],
        "total":    total,
        "page":     page,
        "pages":    (total + per_page - 1) // per_page,
        "per_page": per_page
    })

@app.route("/operator/<callsign>")
def operator(callsign):
    if not db_exists():
        return jsonify({"error": "Database not found"})
    try:
        conn = get_db()
        row  = conn.execute(
            "SELECT uid, call_sign, first_name, last_name, entity_name, street, city, state, zip, "
            "COALESCE(email,'') as email, op_class, status "
            "FROM licenses WHERE call_sign = ?",
            [callsign.upper()]
        ).fetchone()
        conn.close()
    except Exception as e:
        return jsonify({"error": str(e)})

    if not row:
        return jsonify({"error": "Operator not found"})
    return jsonify(dict(row))

@app.route("/stats")
def stats():
    if not db_exists():
        return jsonify({"error": "Database not found"})
    try:
        conn     = get_db()
        total    = conn.execute("SELECT COUNT(*) FROM licenses").fetchone()[0]
        active   = conn.execute("SELECT COUNT(*) FROM licenses WHERE status='Active'").fetchone()[0]
        by_class = conn.execute(
            "SELECT op_class, COUNT(*) as cnt FROM licenses "
            "WHERE op_class != '' GROUP BY op_class ORDER BY cnt DESC"
        ).fetchall()
        by_state = conn.execute(
            "SELECT state, COUNT(*) as cnt FROM licenses "
            "WHERE state != '' GROUP BY state ORDER BY cnt DESC LIMIT 10"
        ).fetchall()
        conn.close()
    except Exception as e:
        return jsonify({"error": str(e)})

    return jsonify({
        "total":      total,
        "active":     active,
        "by_class":   [dict(r) for r in by_class],
        "top_states": [dict(r) for r in by_state]
    })


# ── ADMIN ROUTES ──────────────────────────────────────────────────────────────

@app.route("/admin")
@app.route("/admin/convert")
@admin_required
def admin_convert():
    return send_from_directory(os.path.dirname(os.path.abspath(__file__)), "admin_convert.html")

@app.route("/admin/convert", methods=["POST"])
@admin_required
def admin_convert_upload():
    upload = request.files.get("logfile")
    if not upload or not upload.filename:
        return jsonify({"error": "No file uploaded"}), 400
    suffix = Path(upload.filename).suffix.lower()
    if suffix not in {".log", ".txt"}:
        return jsonify({"error": "Expected a .log or .txt file"}), 400

    text     = upload.read().decode("utf-8", errors="replace")
    defaults = NetDefaults(
        frequency = request.form.get("frequency", "145.470").strip(),
        mode      = request.form.get("mode",      "FM").strip(),
        band      = request.form.get("band",      "2m").strip(),
        net_name  = request.form.get("net_name",  "Vagabond Ragchew Net").strip(),
        dedupe    = request.form.get("dedupe") == "on",
    )

    rows = list(parse_log(text, upload.filename, defaults))
    if not rows:
        return jsonify({"error": "No check-ins found in that file"}), 422

    if request.form.get("archive") == "on":
        _archive_checkins(rows, defaults, upload.filename)

    csv_bytes = rows_to_csv(rows).encode("utf-8")
    out_name  = Path(upload.filename).with_suffix(".csv").name
    return send_file(
        io.BytesIO(csv_bytes),
        mimetype="text/csv",
        as_attachment=True,
        download_name=out_name,
    )

@app.route("/admin/history")
@admin_required
def admin_history_page():
    return send_from_directory(os.path.dirname(os.path.abspath(__file__)), "admin_history.html")

@app.route("/admin/api/history")
@admin_required
def admin_history_data():
    try:
        conn = sqlite3.connect(CHECKINS_DB)
        conn.row_factory = sqlite3.Row
        sessions = conn.execute("""
            SELECT s.id, s.net_date, s.net_time, s.net_name,
                   s.frequency, s.source_file, s.imported_at,
                   COUNT(c.id) AS n_checkins
            FROM sessions s LEFT JOIN checkins c ON c.session_id = s.id
            GROUP BY s.id ORDER BY s.imported_at DESC LIMIT 50
        """).fetchall()
        regulars = conn.execute("""
            SELECT callsign,
                   MAX(operator) AS operator,
                   MAX(state)    AS state,
                   COUNT(DISTINCT session_id) AS sessions_attended
            FROM checkins GROUP BY callsign
            ORDER BY sessions_attended DESC, callsign LIMIT 50
        """).fetchall()
        conn.close()
        return jsonify({
            "sessions": [dict(r) for r in sessions],
            "regulars": [dict(r) for r in regulars],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/admin/api/session/<int:session_id>")
@admin_required
def admin_session_detail(session_id):
    """Return all check-ins for a single session."""
    try:
        conn = sqlite3.connect(CHECKINS_DB)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM checkins WHERE session_id = ? ORDER BY id",
            [session_id]
        ).fetchall()
        conn.close()
        return jsonify({"checkins": [dict(r) for r in rows]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/admin/api/session/<int:session_id>/delete", methods=["POST"])
@admin_required
def admin_session_delete(session_id):
    try:
        conn = sqlite3.connect(CHECKINS_DB)
        conn.execute("DELETE FROM sessions WHERE id = ?", [session_id])
        conn.execute("DELETE FROM checkins WHERE session_id = ?", [session_id])
        conn.commit()
        conn.close()
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def _archive_checkins(rows, defaults, filename):
    conn = sqlite3.connect(CHECKINS_DB)
    cur  = conn.execute(
        "INSERT INTO sessions (net_date,net_time,net_name,frequency,mode,band,source_file) "
        "VALUES (?,?,?,?,?,?,?)",
        (rows[0]["Date"] if rows else "", rows[0]["Time"] if rows else "",
         defaults.net_name, defaults.frequency, defaults.mode,
         defaults.band, filename)
    )
    sid = cur.lastrowid
    conn.executemany(
        "INSERT INTO checkins (session_id,callsign,name,operator,city,state,"
        "county,grid,dxcc,remarks,address,qsl_info) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        [(sid, r["Callsign"], r["Name"], r["Operator"], r["City"], r["State"],
          r["County"], r["Grid"], r["DXCC"], r["Remarks"], r["Address"], r["QSL Info"])
         for r in rows]
    )
    conn.commit()
    conn.close()

# ── LOOKUP HISTORY ────────────────────────────────────────────────────────────

@app.route("/lookup/save", methods=["POST"])
def save_lookup():
    """Record that a callsign was viewed. Called automatically by the front-end."""
    if not db_exists():
        return jsonify({"error": "Database not found"}), 503
    data      = request.get_json(silent=True) or {}
    call_sign = (data.get("call_sign") or "").upper().strip()
    if not call_sign:
        return jsonify({"error": "call_sign required"}), 400
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute(
            "INSERT INTO lookup_history (call_sign, operator_name, op_class, status, city, state) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            [call_sign,
             data.get("operator_name", ""),
             data.get("op_class", ""),
             data.get("status", ""),
             data.get("city", ""),
             data.get("state", "")]
        )
        conn.commit()
        row_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.close()
        return jsonify({"ok": True, "id": row_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/lookup/history")
def lookup_history():
    """Return saved lookup history, newest first. Optional ?q= filter by callsign."""
    if not db_exists():
        return jsonify({"error": "Database not found", "results": [], "total": 0})
    q     = (request.args.get("q") or "").upper().strip()
    limit = min(500, max(1, int(request.args.get("limit", 200))))
    try:
        conn = get_db()
        if q:
            rows = conn.execute(
                "SELECT * FROM lookup_history WHERE call_sign LIKE ? "
                "ORDER BY looked_up_at DESC LIMIT ?",
                [q + "%", limit]
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM lookup_history ORDER BY looked_up_at DESC LIMIT ?",
                [limit]
            ).fetchall()
        total = conn.execute("SELECT COUNT(*) FROM lookup_history").fetchone()[0]
        conn.close()
        return jsonify({"results": [dict(r) for r in rows], "total": total})
    except Exception as e:
        return jsonify({"error": str(e), "results": [], "total": 0})


@app.route("/lookup/note/<int:entry_id>", methods=["POST"])
def update_note(entry_id):
    """Save a note against a history entry."""
    if not db_exists():
        return jsonify({"error": "Database not found"}), 503
    data = request.get_json(silent=True) or {}
    note = data.get("note", "")
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("UPDATE lookup_history SET notes = ? WHERE id = ?", [note, entry_id])
        conn.commit()
        conn.close()
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/lookup/delete/<int:entry_id>", methods=["POST"])
def delete_lookup(entry_id):
    """Remove a single history entry."""
    if not db_exists():
        return jsonify({"error": "Database not found"}), 503
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("DELETE FROM lookup_history WHERE id = ?", [entry_id])
        conn.commit()
        conn.close()
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/lookup/clear", methods=["POST"])
def clear_history():
    """Wipe all history entries."""
    if not db_exists():
        return jsonify({"error": "Database not found"}), 503
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.execute("DELETE FROM lookup_history")
        conn.commit()
        conn.close()
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/scheduler/status")
def scheduler_status():
    """Return the scheduler's live status (next rebuild countdown, last run, etc.)"""
    status_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scheduler_status.json")
    try:
        with open(status_file) as f:
            data = json.load(f)
        # Recalculate live countdown
        next_dt = datetime.fromisoformat(data["next_rebuild_at"])
        data["next_rebuild_in_s"] = max(0, int((next_dt - datetime.now()).total_seconds()))
        return jsonify(data)
    except FileNotFoundError:
        return jsonify({"error": "Scheduler not running", "next_rebuild_in_s": None})
    except Exception as e:
        return jsonify({"error": str(e)})


@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": str(e)}), 500

# ── ENTRY POINT ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not db_exists():
        print("=" * 60)
        print("  Database not found!")
        print("  Run this first:  python import_data.py")
        print("=" * 60)
    else:
        print(f"Database: {DB_PATH}")
    print("\n  ► Flask running on http://127.0.0.1:8080 (proxied via nginx to http://localhost)\n")
    app.run(debug=False, host="127.0.0.1", port=8080)
